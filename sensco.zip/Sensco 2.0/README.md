Lingulo-Responsive-Tutorial
===========================

HTML5 Responsive Website Tutorial by http://www.lingulo.com

This HTML5 website is part of a HTML5 / CSS3 tutorial created by Christoph Anastasiades (http://www.lingulo.com/tutorials/css/how-to-build-a-html5-website-from-scratch)
Feel free to use it for your personal or commercial projects and/or change it in any way you like.

I would be happy if you put a link to http://www.lingulo.com somewhere on your website to support my work.




<br/><br/>
<b>What you need to do to make this page work</b>:
<ul>
<li>Find images for the jQuery Slider from http://www.open-image.net and for all the icons (the icons used in the tutorial are from http://www.iconarchive.com/show/icons8-metro-style-icons-by-visualpharm.1.html) or even better use a font like FontAwesome for the icons</li>
<li>To minimize the amount of HTTP requests combine all CSS files into one single file</li></ul>
